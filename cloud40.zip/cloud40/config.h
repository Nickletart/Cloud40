#pragma once

#define EE_HANDS

#define MATRIX_ROWS 8
#define MATRIX_COLS 12

#define MATRIX_ROW_PINS { B1, B3, B2, B6 }
//#define MATRIX_COL_PINS { D4, C6, D7, E6, B4, B5 }
#define MATRIX_COL_PINS { B5, B4, E6, D7, C6, D4 }

#define SOFT_SERIAL_PIN D0
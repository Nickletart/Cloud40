// Copyright 2023 QMK
// SPDX-License-Identifier: GPL-2.0-or-later

#include QMK_KEYBOARD_H

enum custom_keycodes {
    CYCLE_LAYERS = SAFE_RANGE,  // Start custom keycodes from SAFE_RANGE
};

enum layers {
    BASE,
    LAYER_1,
    LAYER_2
};

const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
    
    [BASE] = LAYOUT(

        // Left half
        KC_ESC,    KC_Q,    KC_W,    KC_E,    KC_R,    KC_T,      // Row 1
        KC_TAB,    KC_A,    KC_S,    KC_D,    KC_F,    KC_G,      // Row 2
        KC_LSFT,   KC_Z,    KC_X,    KC_C,    KC_V,    KC_B,      // Row 3
        KC_NO,     KC_NO,   KC_NO,   KC_NO,   KC_LCTL, CYCLE_LAYERS, // Row 4

        // Right half
        KC_BSPC,   KC_P,    KC_O,    KC_I,    KC_U,    KC_Y,      // Row 1
        KC_QUOT,   KC_SCLN, KC_L,    KC_K,    KC_J,    KC_H,      // Row 2
        KC_ENT,    KC_SLSH, KC_DOT,  KC_COMM, KC_M,    KC_N,      // Row 3
        KC_NO,     KC_NO,   KC_NO,   KC_NO,   KC_RALT, KC_SPC     // Row 4

    ),
    
    [LAYER_1] = LAYOUT(

        // Left half
        KC_ESC,    KC_1,    KC_2,    KC_3,    KC_4,    KC_5,      // Row 1
        KC_TAB,    KC_PAUS, KC_MPRV, KC_VOLU, KC_VOLD, KC_MNXT,   // Row 2
        KC_LSFT,   KC_CAPS, KC_CALC, KC_BRID, KC_BRIU, KC_MPLY,   // Row 3
        KC_NO,     KC_NO,   KC_NO,   KC_NO,   KC_LCTL, CYCLE_LAYERS, // Row 4

        // Right half
        KC_BSPC,   KC_0,    KC_9,    KC_8,    KC_7,    KC_6,      // Row 1
        KC_NO,     KC_DEL,  KC_RIGHT,KC_UP,   KC_DOWN, KC_LEFT,   // Row 2
        KC_ENT,    KC_PSCR, KC_PGUP, KC_PGDN, KC_NO,   KC_NO,     // Row 3
        KC_NO,     KC_NO,   KC_NO,   KC_NO,   KC_RALT, KC_SPC     // Row 4

    ),

    [LAYER_2] = LAYOUT(

        // Left half
        KC_ESC,    KC_F1,   KC_F2,   KC_F3,   KC_F4,   KC_F5,     // Row 1
        KC_TAB,    KC_F6,   KC_F7,   KC_F8,   KC_F9,   KC_F10,    // Row 2
        KC_LSFT,   KC_NO,   KC_NO,   KC_NO,   KC_NO,   KC_NO,     // Row 3
        KC_NO,     KC_NO,   KC_NO,   KC_NO,   KC_LCTL, CYCLE_LAYERS,   // Row 4

        // Right half
        KC_GRV,    KC_BSLS, KC_RBRC, KC_LBRC, KC_EQL,  KC_MINS,   // Row 1
        KC_NO,     KC_NO,   KC_NO,   KC_NO,   KC_NO,   KC_NO,    // Row 2
        KC_NO,     KC_NO,   KC_NO,   KC_NO,   KC_NO,   KC_NO,    // Row 3
        KC_NO,     KC_NO,   KC_NO,   KC_NO,   KC_RALT, KC_SPC    // Row 4

    )
};

// Variable to track the current layer
static uint8_t current_layer = BASE;

bool process_record_user(uint16_t keycode, keyrecord_t *record) {
    if (record->event.pressed) {
        switch (keycode) {
            case CYCLE_LAYERS:
                // Cycle through layers (BASE -> LAYER_1 -> LAYER_2 -> BASE)
                switch (current_layer) {
                    case BASE:
                        layer_on(LAYER_1);  // Activate LAYER_1
                        layer_off(BASE);    // Deactivate BASE layer
                        current_layer = LAYER_1; // Set current layer to LAYER_1
                        break;
                    case LAYER_1:
                        layer_on(LAYER_2);  // Activate LAYER_2
                        layer_off(LAYER_1); // Deactivate LAYER_1
                        current_layer = LAYER_2; // Set current layer to LAYER_2
                        break;
                    case LAYER_2:
                        layer_off(LAYER_2);  // Deactivate LAYER_2
                        layer_on(BASE);      // Activate BASE layer
                        current_layer = BASE; // Set current layer to BASE
                        break;
                }
                return false; // Prevent further action for the key
            default:
                break;
        }
    }
    return true;
}
